import java.util.Arrays;

public class rotateArray {
    public static void main(String[] args){
    int array_num[] = {20, 30, 40};
	System.out.println("Original Array: "+Arrays.toString(array_num)); 
	int[] new_array_num = {array_num[1], array_num[2], array_num[0]};
	System.out.println("Rotated Array: "+Arrays.toString(new_array_num)); 	 
 }
}
