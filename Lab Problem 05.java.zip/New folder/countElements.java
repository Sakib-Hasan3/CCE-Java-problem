import java.util.Arrays;

public class countElements {
    public static void main(String[] args)
 {
	int array_num1[] = {10, 11, 10, 20, 43, 20, 50};
	int array_num2[] = {10, 13, 11, 20, 44, 30, 50};
	System.out.println("Array1: "+Arrays.toString(array_num1)); 
	System.out.println("Array2: "+Arrays.toString(array_num2)); 
	int ctr = 0;
    for(int i = 0; i < array_num1.length; i++) {
        if(Math.abs(array_num1[i] - array_num2[i]) <= 1 && array_num1[i] != array_num2[i])
            ctr++;
    }      
    System.out.printf("Number of elements: "+ctr);
  }
}
