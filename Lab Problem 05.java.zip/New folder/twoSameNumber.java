public class twoSameNumber {
    public static void main(String[] args)
 {
	  int array_num[] = {10, 20, 10, 50, 20, 13, 50};
	  int result=0;
	  int x = 10;
	for(int i = 0; i < array_num.length - 1; i++) {
        if(array_num[i] == x && array_num[i+1] == x)
            {
         System.out.printf( String.valueOf(true));	
         result = 1 ;
		}
        if(i <= array_num.length - 3 && array_num[i] == x && array_num[i+2] == x)
           {
         System.out.printf( String.valueOf(true));	
         result = 1 ;
		}
    }
	 if (result==0)                             
	   {	 
         System.out.printf( String.valueOf(false));
	    }
    }
}
