import java.util.Arrays;

public class oddBeforeEven {
    public static void main(String[] args)
 {
    int array_num[] = {1, 7, 8, 5, 7, 13, 0, 2, 4, 9};
	int i = 0;
    System.out.println("Original Array: "+Arrays.toString(array_num)); 
    while(i < array_num.length && array_num[i] % 2 == 0)
        i++;
    for(int j = i + 1; j < array_num.length; j++) {
        if(array_num[j] % 2 != 0) {
            int temp = array_num[i];
            array_num[i] = array_num[j];
            array_num[j] = temp;
            i++;
        }
    }                                                    
	 System.out.println("New Array: "+Arrays.toString(array_num)); 
  }
}
