import java.util.Arrays;

public class largestElement {
    public static void main(String[] args)
 {
    int[] array_num = {20, 30, 40, 50, 67};
	System.out.println("Original Array: "+Arrays.toString(array_num)); 
	int max_val = array_num[0];
	if(max_val <= array_num[array_num.length-1])
		max_val = array_num[array_num.length-1];
	if(max_val <= array_num[array_num.length/2])
		max_val = array_num[array_num.length/2];
	System.out.println("Largest element between first, last, and middle values: "+max_val);  
 }
}
