import java.util.Arrays;

public class containArrayLength {
    public static void main(String[] args){
    int array_num[] = {5, 7};
	System.out.println("Original Array: "+Arrays.toString(array_num)); 
	if(array_num[0] == 4 || array_num[0] == 7)
		System.out.println("True");
	else
    System.out.println(array_num[1] == 4 || array_num[1] == 7);
 }
}
