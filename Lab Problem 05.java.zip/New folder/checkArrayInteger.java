public class checkArrayInteger {
    public static void main(String[] args)
 {
	  int array_num[] = {10, 70, 80, 50, 20, 13, 50};
      boolean testd = false;
	  int result=0;
	  int x = 10;
	  int y = 20;
    
    for(int i = 0; i < array_num.length; i++) {
        if(array_num[i] == x)
            testd = true;
        if(testd && array_num[i] == y)
		{
         System.out.printf( String.valueOf(true));	
         result = 1		 ;
		}
    }
     if (result==0)                             
	   {	 
         System.out.printf( String.valueOf(false));
	    }
    }
}
