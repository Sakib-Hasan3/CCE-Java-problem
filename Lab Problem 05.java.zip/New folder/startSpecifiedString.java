public class startSpecifiedString {
    public static void main(String[] args)
 {
   String s1 = "Hello how are you?";
    System.out.println(s1.startsWith("Hello"));
  }
}
