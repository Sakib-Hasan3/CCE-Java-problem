public class currentSystemEnvironment {
    public static void main(String[] args)
 {
        System.out.println("Current system environment:");
         System.out.println(System.getenv());	 
	System.out.println("Current system properties:");
    System.out.println(System.getProperties());	
  }
}
