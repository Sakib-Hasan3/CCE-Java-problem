
 public class removeString {
 public static void main(String[] args)
 {
    String str1 = "Python";    
	String str2 = "Tutorial"; 
	
	System.out.println(str1.substring(1) + str2.substring(1));
	} 
}
