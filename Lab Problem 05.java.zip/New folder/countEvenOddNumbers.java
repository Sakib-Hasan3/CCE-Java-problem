import java.util.Arrays;

public class countEvenOddNumbers {
    public static void main(String[] args)
 {
    int num[] = {5, 7, 2, 4, 9};
	int ctr_even = 0, ctr_odd = 0;
	System.out.println("Original Array: "+Arrays.toString(num)); 
	    
    for(int i = 0; i < num.length; i++) {
        if(num[i] % 2 == 0)
		{         
          ctr_even++;
		}
		else
		   ctr_odd++;	
    }                 
    System.out.printf("Number of even elements in the array: %d\n",ctr_even);
	System.out.printf("Number of odd elements in the array: %d\n",ctr_odd);
  }
}
