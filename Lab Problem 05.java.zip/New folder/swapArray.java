import java.util.Arrays;

public class swapArray {
    public static void main(String[] args)
 {
    int[] array_num = {20, 30, 40};
	System.out.println("Original Array: "+Arrays.toString(array_num)); 
	int x = array_num[0];
	array_num[0] = array_num[array_num.length-1];
	array_num[array_num.length-1] = x;
	System.out.println("New array after swaping the first and last elements: "+Arrays.toString(array_num));  
 }
}
