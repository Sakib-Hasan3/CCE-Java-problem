public class addLastThreeDigit {
    public static void main(String[] args)
 {
   String s1 = "Python";
    int slength = 3;
    if (slength > s1.length()) {
      slength = s1.length();
    }

    String subpart = s1.substring(s1.length()-3);
    System.out.println(subpart + s1 + subpart);
  }
}
