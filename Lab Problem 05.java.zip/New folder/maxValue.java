import java.util.Arrays;

public class maxValue {
    public static void main(String[] args)
 {
    int array_num[] = {20, 30, 40};
	System.out.println("Original Array: "+Arrays.toString(array_num)); 
	int max_val = array_num[0];
	if(array_num[2] >= max_val)
		max_val = array_num[2];
	System.out.println("Larger value between first and last element: "+max_val); 	 
 }
}
