import java.util.Scanner;

public class convertLowercase {
    public static void main(String[] args){	
     Scanner input = new Scanner(System.in);
     System.out.print("Input a String: ");
	 String line = input.nextLine();
	 line = line.toLowerCase();
	 System.out.println(line); 
	 }			
}
