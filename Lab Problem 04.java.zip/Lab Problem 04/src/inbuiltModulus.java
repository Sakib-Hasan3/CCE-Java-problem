import java.util.Scanner;

public class inbuiltModulus {
     public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Input the first number : ");
        int a = input.nextInt();  
		System.out.print("Input the second number: ");
		int b = input.nextInt(); 
		int divided = a / b;
		int result = a - (divided * b);
		System.out.println(result); 
	}
}
