import java.util.Scanner;

public class countFactorsNumber {
    public static void main(String[] args){
      Scanner input = new Scanner(System.in);
      System.out.print("Input an integer: ");
      int x = input.nextInt(); 

		System.out.println(result(x));
	 } 		
	public static int result(int num) {	
		int count = 0;
        for(int i=1; i<=(int)Math.sqrt(num); i++) {
            if(num%i==0 && i*i!=num) {
                count+=2;
            } else if (i*i==num) {
                count++;
            }
        }
        return count;
	}
}
