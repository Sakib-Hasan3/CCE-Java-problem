import java.util.*; 
public class greaterNumber {
 public static void main(String[] args)
 {
	int array_num[] = {10, 11, 10, 30, 45, 20, 33, 53};
	System.out.println("Original Array: "+Arrays.toString(array_num)); 
    
	int ctr1 = 0;
    int ctr2 = 0;
      
    for(int i = 0; i < array_num.length; i++) {
        if(array_num[i] == 10)
            ctr1++;
                        
        if(array_num[i] == 20)
            ctr2++;
    }                                      
    System.out.printf(String.valueOf(ctr1 > ctr2));
  }
}