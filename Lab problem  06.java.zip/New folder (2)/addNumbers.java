import java.util.Scanner;

public class addNumbers {
    public static void main(String[] arg){
	   int x,y ;
	   Scanner input = new Scanner(System.in);	
	   System.out.print("Input first number: ");
	   x = input.nextInt(); 
	   System.out.print("Input second number: ");
	   y = input.nextInt(); 
      while(y != 0){
            int carry = x & y;
            x = x ^ y;
            y = carry << 1;
        }
        System.out.print("Sum: "+x);     	
	}	
}
