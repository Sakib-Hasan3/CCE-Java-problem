import java.util.*; 
public class checkStartAndEndSame {
    public static void main(String[] args)
    {
       int array_num[] = {11, 15, 13, 10, 45, 20, 11, 15};
       System.out.println("Original Array: "+Arrays.toString(array_num)); 
       int result = 0;
       int l = 2;
       int start = 0;
       int end = array_num.length-l;
       for(; l > 0; l--)
       {
           if(array_num[start] != array_num[end])
               result = 1;
           else
           {
               start++;
               end++;
           }
       }       
       if (result==1)
        {
         System.out.printf(String.valueOf(false));
        }
       else
        {
          System.out.printf(String.valueOf(true));
        }
    } 
}
