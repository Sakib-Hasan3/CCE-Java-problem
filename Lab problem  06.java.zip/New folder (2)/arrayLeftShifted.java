import java.util.Arrays;
public class arrayLeftShifted {
    public static void main(String[] args){
	int array_num[] = {11, 15, 13, 10, 45, 20};
    System.out.println("Original Array: "+Arrays.toString(array_num)); 
	if(array_num.length >1) {          
    int first = array_num[0];    
    for(int i = 1; i < array_num.length; i++)
        array_num[i - 1] = array_num[i];            
    array_num[array_num.length - 1] = first;
	System.out.println("New Array: "+Arrays.toString(array_num)); 
	}
  }
}
