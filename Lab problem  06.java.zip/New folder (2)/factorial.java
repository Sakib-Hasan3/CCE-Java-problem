import java.util.Scanner;

public class factorial {
    public static void main(String[] arg) {
		Scanner input = new Scanner(System.in);	
		System.out.print("Input a number: ");
	    int n = input.nextInt(); 
        int n1 = n;
		long count = 0;
		while (n != 0) 
		{
			count += n / 5;
			n /= 5;
		}
		System.out.printf("Number of trailing zeros of the factorial %d is %d ",n1,count);     	   
	}	
}
