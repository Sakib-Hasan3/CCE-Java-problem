import java.util.Arrays;

public class checkSpecifiedValue {
    public static void main(String[] args)
 {
	int array_num[] = {11, 11, 13, 31, 45, 20, 33, 53};
    int result = 1; 
	System.out.println("Original Array: "+Arrays.toString(array_num)); 
	for(int i = 0; i < array_num.length; i++)
     {
      	if(array_num[i] == 10 || array_num[i] == 30)
		{	
		   result =0;
		}
      }
	 if (result==1)
 	   System.out.printf( String.valueOf(false));	         
     else
	   System.out.printf(String.valueOf(true));
  }
}
