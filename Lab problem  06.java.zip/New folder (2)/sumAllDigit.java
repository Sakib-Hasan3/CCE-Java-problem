import java.util.Scanner;

public class sumAllDigit {
    public static void main(String[] arg) {	
        Scanner input = new Scanner(System.in);	
       System.out.print("Input a positive integer: ");
        int n = input.nextInt(); 
		int sum = 0;
		while(n!=0)
        {
            int r = n % 10;
            sum = sum + r;
            n = n / 10;
        }
        System.out.printf("sum of all digit:%d\n",sum);
    }
}
