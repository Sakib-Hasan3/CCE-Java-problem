import java.util.Arrays;

public class increasingArray {
     public static void main(String[] args){
	int array_num[] = {11, 12, 13, 14, 45, 20};
    System.out.println("Original Array: "+Arrays.toString(array_num)); 
	int result =1;
      for(int i = 0; i <= array_num.length - 3; i++) {
        if(array_num[i] + 1 == array_num[i+1] && array_num[i+1] + 1 == array_num[i+2])
            result =0;
    }        
	if (result==1)
	 {
	  System.out.printf(String.valueOf(false));
	 }
	else
	 {
	   System.out.printf(String.valueOf(true));
	 }
 }
}
