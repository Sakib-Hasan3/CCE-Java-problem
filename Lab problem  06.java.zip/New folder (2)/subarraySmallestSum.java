import java.util.ArrayList;

public class subarraySmallestSum {
   public static void main(String[] args) {
     ArrayList<Integer> num = new ArrayList<Integer>();
      num.add(-2);
      num.add(1);
      num.add(-3);
      num.add(4);
      System.out.print(min_SubArray(num)); 
}
 public static int min_SubArray(ArrayList<Integer> num) { 
   int num1[] = new int[num.size()];
        num1[0] = num.get(0);
        int min = num1[0];
        for (int i = 1; i < num.size(); ++i) {
            num1[i] = Math.min(num.get(i), num.get(i) + num1[i - 1]);
            min = Math.min(min, num1[i]);
        }
        return min;
 } 
}
